Original mod backup placeholder.
No original mod archive was available in the conversation or accessible file library, so no backup could be created.

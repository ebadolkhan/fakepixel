# iEbadol Smooth FPS Reducer

A conservative, client-only Minecraft Forge 1.8.9 mod project.

## Target
- Minecraft 1.8.9
- Forge 11.15.1.2318
- Java 8 runtime/build target
- Intended use: Zalith Launcher on Android; device-specific performance is not guaranteed

## Features
- Uses Minecraft's built-in minimal-particles setting when enabled.
- Disables entity shadows when enabled.
- Allows a configurable render distance and FPS cap.
- Captures the previous vanilla settings and restores them when leaving a world.
- Does not replace textures, modify resource packs, alter SkyBlock data, or change gameplay mechanics.
- Contains no Discord webhook, chat tracking, telemetry, analytics, or data-sharing code.

## Configuration
Edit `config/iEbadol_Smooth_FPS_Mod.cfg` or the generated file in `.minecraft/config/`.

- `reduceParticles`: true/false
- `disableEntityShadows`: true/false
- `renderDistanceChunks`: 2-16; use 0 to leave unchanged
- `fpsLimit`: 30-120; use 0 to leave unchanged

Restart Minecraft after changing the config. The default 8-chunk distance and 60 FPS cap are conservative starting points, not guaranteed optimal values for every device/server.

## Build
This is a ForgeGradle 2.1 project targeting Java 8. Use a Java 8 JDK and Gradle 2.14.1, then run:

```sh
gradle setupDecompWorkspace
gradle build
```

The output JAR should be under `build/libs/`.

## Test status
The source and project metadata are packaged, but this delivery environment had no Gradle installation, no Java 8 JDK, and no DNS/network access to retrieve ForgeGradle or Forge dependencies. Therefore the mod JAR could not be compiled, and Minecraft startup/in-game compatibility tests could not be run here. Do not treat this source package as a tested binary.

## Memory note
The mod deliberately does not call `System.gc()`, rewrite heap limits, or manipulate internal Minecraft memory structures. Those approaches can increase stutter or cause crashes. Memory use is left to the launcher/JVM and Minecraft's normal resource lifecycle.

package com.iebadol.smoothfps;

import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.io.File;

@Mod(modid = SmoothFpsMod.MODID, name = SmoothFpsMod.NAME, version = SmoothFpsMod.VERSION,
        acceptedMinecraftVersions = "[1.8.9]", clientSideOnly = true)
public final class SmoothFpsMod {
    public static final String MODID = "iebadol_smooth_fps";
    public static final String NAME = "iEbadol Smooth FPS Reducer";
    public static final String VERSION = "1.0.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        File configFile = new File(event.getModConfigurationDirectory(), "iEbadol_Smooth_FPS_Mod.cfg");
        ModConfig.load(configFile);
        if (event.getSide() == Side.CLIENT) {
            ClientOptimizer optimizer = new ClientOptimizer();
            FMLCommonHandler.instance().bus().register(optimizer);
            MinecraftForge.EVENT_BUS.register(optimizer);
        }
    }
}
